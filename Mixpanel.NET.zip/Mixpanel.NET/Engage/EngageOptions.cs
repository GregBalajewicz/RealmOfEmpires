using Mixpanel.NET.Events;

namespace Mixpanel.NET.Engage {
  public class EngageOptions : MixpanelClientOptions {}
}